/*
 * Requiem
 * Copyright (C) 2017-2023 Ladysnake
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * License for more details.
 *
 * You should have received a copy of the GNU License
 * along with this program. If not, see <https://www.gnu.org/licenses>.
 *
 * Linking this mod statically or dynamically with other
 * modules is making a combined work based on this mod.
 * Thus, the terms and conditions of the GNU General Public License cover the whole combination.
 *
 * In addition, as a special exception, the copyright holders of
 * this mod give you permission to combine this mod
 * with free software programs or libraries that are released under the GNU LGPL
 * and with code included in the standard release of Minecraft under All Rights Reserved (or
 * modified versions of such code, with unchanged license).
 * You may copy and distribute such a system following the terms of the GNU GPL for this mod
 * and the licenses of the other code concerned.
 *
 * Note that people who make modified versions of this mod are not obligated to grant
 * this special exception for their modified versions; it is their choice whether to do so.
 * The GNU General Public License gives permission to release a modified version without this exception;
 * this exception also makes it possible to release a modified version which carries forward this exception.
 */
package ladysnake.requiem.core.entity.ability;

import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.Snowball;

public class SnowmanSnowballAbility<T extends LivingEntity> extends IndirectAbilityBase<T> {
    public SnowmanSnowballAbility(T owner) {
        super(owner, 20);
    }

    @Override
    public boolean run() {
        if (!this.owner.level().isClientSide()) {
            Snowball snowball = new Snowball(this.owner.level(), this.owner);
            snowball.shootFromRotation(this.owner, this.owner.getXRot(), this.owner.getYRot(), 0.0F, 1.5F, 1.0F);
            this.owner.playSound(SoundEvents.SNOW_GOLEM_SHOOT, 1.0F, 1.0F / (this.owner.getRandom().nextFloat() * 0.4F + 0.8F));
            this.owner.level().addFreshEntity(snowball);
            this.beginCooldown();
        }
        return true;
    }
}
