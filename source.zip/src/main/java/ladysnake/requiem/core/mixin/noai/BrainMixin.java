package ladysnake.requiem.core.mixin.noai;

import ladysnake.requiem.core.entity.ai.DisableableAiController;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.Brain;
import net.minecraft.world.entity.ai.memory.MemoryModuleType;
import net.minecraft.world.entity.ai.memory.MemoryStatus;
import net.minecraft.server.level.ServerLevel;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.Optional;

@Mixin(Brain.class)
public abstract class BrainMixin implements DisableableAiController {
    @Unique
    private boolean disabled;

    @Override
    public void requiem$setDisabled(boolean disabled) {
        this.disabled = disabled;
    }

    @Inject(method = "tick", at = @At("HEAD"), cancellable = true)
    private void tick(ServerLevel world, LivingEntity entity, CallbackInfo ci) {
        if (this.disabled) {
            ci.cancel();
        }
    }

    @Inject(method = "checkMemory", at = @At("HEAD"), cancellable = true)
    private void checkMemory(MemoryModuleType<?> type, MemoryStatus state, CallbackInfoReturnable<Boolean> cir) {
        if (this.disabled) {
            cir.setReturnValue(false);
        }
    }

    @Inject(method = "getMemory(Lnet/minecraft/world/entity/ai/memory/MemoryModuleType;)Ljava/util/Optional;", at = @At("HEAD"), cancellable = true)
    private void getMemory(MemoryModuleType<?> type, CallbackInfoReturnable<Optional<?>> cir) {
        if (this.disabled) {
            cir.setReturnValue(Optional.empty());
        }
    }
}
