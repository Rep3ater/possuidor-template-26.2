package ladysnake.requiem.common.locki;

import ladysnake.requiem.common.item.RequiemItems;
import ladysnake.requiem.common.network.RequiemNetworking;
import net.minecraft.core.BlockPos;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.Container;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.EntityTypes;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.CustomData;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.event.ServerChatEvent;
import net.neoforged.neoforge.event.entity.living.LivingIncomingDamageEvent;

import java.util.Locale;

/** Marbas' embryo, homunculus soul/program, and cauldron rituals. The default body uses the vanilla wolf model until custom assets arrive. */
public final class MarbasAbilitySystem {
    public static final String TAG = "marbas";
    public static final String HOMUNCULUS = "requiem:homunculus";
    public static final String BRAIN = "requiem:homunculus_brain";
    public static final String BORN_AT = "requiem:homunculus_born_at";
    public static final String HOME = "requiem:homunculus_home";
    public static final String OWNER = "requiem:homunculus_owner";
    public static final String BERSERK = "requiem:suffering_berserk";
    private static final String NODE = "requiem:homunculus_node";
    private static final String TARGET_ID = "requiem:homunculus_target_id";
    private static final String STUN_UNTIL = "requiem:homunculus_stun_until";
    private static final String FED_UNTIL = "requiem:homunculus_fed_until";
    private static final String TRAITS = "requiem:homunculus_traits";

    private MarbasAbilitySystem() {}

    public static boolean isMarbas(Player player) {
        return player != null && (player.entityTags().contains(TAG) || player.entityTags().contains("Marbas"));
    }

    public static void onChat(ServerChatEvent event) {
        ServerPlayer player = event.getPlayer();
        if (!isMarbas(player)) return;
        String phrase = event.getRawText().trim().toLowerCase(Locale.ROOT);
        if (!phrase.equals("embryo") && !phrase.equals("fetus")) return;
        event.setCanceled(true);
        ItemStack head = findNamedPlayerHead(player);
        if (head.isEmpty()) {
            player.sendSystemMessage(Component.literal("Hold a player head named `Embryo` or `Fetus`, then say that word again."));
            return;
        }
        if (!player.getAbilities().instabuild) head.shrink(1);
        ItemStack embryo = new ItemStack(RequiemItems.EMBRYO);
        embryo.set(DataComponents.CUSTOM_NAME, Component.literal(phrase.equals("fetus") ? "Fetus" : "Embryo"));
        CustomData.update(DataComponents.CUSTOM_DATA, embryo, tag -> {
            tag.putString(BRAIN, "return home");
            tag.putString(OWNER, player.getUUID().toString());
            tag.putString("requiem:donor_head_name", "Embryo");
        });
        if (!player.getInventory().add(embryo)) player.drop(embryo, false);
        player.sendSystemMessage(Component.literal("A named Embryo has been prepared. Place it in a water-filled cauldron to grow a homunculus."));
    }

    private static ItemStack findNamedPlayerHead(Player player) {
        for (ItemStack stack : player.getInventory().getNonEquipmentItems()) {
            if (!stack.is(Items.PLAYER_HEAD)) continue;
            String name = stack.getHoverName().getString().toLowerCase(Locale.ROOT);
            if (name.contains("embryo") || name.contains("fetus")) return stack;
        }
        return ItemStack.EMPTY;
    }

    /** Called from the right-click-block event before ordinary incorporeal restrictions. */
    public static boolean onUseBlock(ServerPlayer player, ItemStack stack, BlockPos pos, boolean shift) {
        if (!isMarbas(player) || !(player.level() instanceof ServerLevel level)) return false;
        BlockState clicked = level.getBlockState(pos);
        if (!clicked.is(Blocks.WATER_CAULDRON)) return false;

        if (stack.is(RequiemItems.EMBRYO)) {
            growHomunculus(level, pos, player, readItemData(stack).getString(BRAIN).orElse("return home"), readItemData(stack).getString(TRAITS).orElse(""));
            if (!player.getAbilities().instabuild) stack.shrink(1);
            level.setBlock(pos, Blocks.CAULDRON.defaultBlockState(), 3);
            player.sendSystemMessage(Component.literal("The embryo develops into a homunculus."));
            return true;
        }

        if (stack.is(RequiemItems.HOMUNCULUS) && player.getOffhandItem().is(RequiemItems.SUFFERING_HEAD)) {
            Mob mob = growHomunculus(level, pos, player, "", "suffering");
            if (mob != null) mob.getPersistentData().putBoolean(BERSERK, true);
            if (!player.getAbilities().instabuild) { stack.shrink(1); player.getOffhandItem().shrink(1); }
            level.setBlock(pos, Blocks.CAULDRON.defaultBlockState(), 3);
            player.sendSystemMessage(Component.literal("The Suffering Head fuses with the homunculus. It is immortal, unstable, and will ignore its programmed brain."));
            return true;
        }

        if (stack.is(RequiemItems.HOMUNCULUS) && isMobHead(player.getOffhandItem())) {
            String headName = player.getOffhandItem().getHoverName().getString();
            String traits = traitsForHead(player.getOffhandItem());
            String program = readItemData(stack).getString(BRAIN).orElse("return home");
            Mob mob = growHomunculus(level, pos, player, program, traits);
            if (mob != null) mob.getPersistentData().putString(TRAITS, traits);
            if (!player.getAbilities().instabuild) { stack.shrink(1); player.getOffhandItem().shrink(1); }
            level.setBlock(pos, Blocks.CAULDRON.defaultBlockState(), 3);
            player.sendSystemMessage(Component.literal("The homunculus inherits traits from " + headName + "."));
            return true;
        }

        if (stack.is(RequiemItems.SULFUR_CUBE)) {
            Mob homunculus = level.getEntitiesOfClass(Mob.class, new AABB(pos).inflate(5.0), MarbasAbilitySystem::isHomunculus)
                .stream().findFirst().orElse(null);
            if (homunculus == null) {
                player.sendSystemMessage(Component.literal("Put an Embryo in this water cauldron first, or bring a homunculus close to it."));
                return true;
            }
            if (!player.getAbilities().instabuild) stack.shrink(1);
            String program = homunculus.getPersistentData().getString(BRAIN).orElse("return home");
            RequiemNetworking.sendHomunculusBrainOpen(player, homunculus.getId(), program);
            return true;
        }
        return false;
    }

    private static CompoundTag readItemData(ItemStack stack) {
        return stack.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag();
    }

    private static Mob growHomunculus(ServerLevel level, BlockPos cauldron, ServerPlayer owner, String brain, String traits) {
        Entity entity = EntityTypes.WOLF.create(level, EntitySpawnReason.TRIGGERED);
        if (!(entity instanceof Mob mob)) return null;
        mob.setPos(cauldron.getX() + 0.5, cauldron.getY() + 1.0, cauldron.getZ() + 0.5);
        mob.setCustomName(Component.literal("Homunculus"));
        mob.setCustomNameVisible(true);
        mob.setPersistenceRequired();
        CompoundTag data = mob.getPersistentData();
        data.putBoolean(HOMUNCULUS, true);
        data.putString(BRAIN, brain == null || brain.isBlank() ? "return home" : brain);
        data.putString(TRAITS, traits == null ? "" : traits);
        data.putString(OWNER, owner.getUUID().toString());
        data.putLong(BORN_AT, level.getGameTime());
        data.putString(HOME, cauldron.getX() + " " + (cauldron.getY() + 1) + " " + cauldron.getZ());
        var health = mob.getAttribute(Attributes.MAX_HEALTH);
        if (health != null && traits != null && traits.contains("health")) health.setBaseValue(80.0);
        mob.setHealth(mob.getMaxHealth());
        if (!level.addFreshEntity(mob)) return null;
        return mob;
    }

    public static boolean onEntityInteract(Player player, Entity target, ItemStack held, boolean shift) {
        if (!(player instanceof ServerPlayer serverPlayer) || !(player.level() instanceof ServerLevel level)) return false;
        if (target instanceof Mob homunculus && isHomunculus(homunculus) && held.is(Items.GOLD_INGOT)
                && homunculus.getPersistentData().getString(TRAITS).orElse("").contains("trade_gold")) {
            if (!serverPlayer.getAbilities().instabuild) held.shrink(1);
            ItemStack trade = switch (serverPlayer.getRandom().nextInt(5)) {
                case 0 -> new ItemStack(Items.QUARTZ, 2 + serverPlayer.getRandom().nextInt(4));
                case 1 -> new ItemStack(Items.BLACKSTONE, 2 + serverPlayer.getRandom().nextInt(4));
                case 2 -> new ItemStack(Items.STRING, 2 + serverPlayer.getRandom().nextInt(4));
                case 3 -> new ItemStack(Items.SOUL_SAND, 1 + serverPlayer.getRandom().nextInt(3));
                default -> new ItemStack(Items.IRON_NUGGET, 3 + serverPlayer.getRandom().nextInt(6));
            };
            homunculus.spawnAtLocation(level, trade);
            serverPlayer.sendSystemMessage(Component.literal("The homunculus barters for gold."));
            return true;
        }
        if (!isMarbas(player)) return false;
        if (held.is(RequiemItems.VESSEL_SHARD) && target instanceof Mob mob && isHomunculus(mob)) {
            long born = mob.getPersistentData().getLong(BORN_AT).orElse(level.getGameTime());
            int sleeps = player.getPersistentData().getInt("requiem:marbas_sleep_count").orElse(0);
            if (level.getGameTime() - born > 48000L && sleeps < 2) {
                player.sendSystemMessage(Component.literal("The homunculus soul has settled. It can be extracted during its first two days, or after two nights of sleep."));
                return true;
            }
            ItemStack fetus = new ItemStack(RequiemItems.EMBRYO);
            fetus.set(DataComponents.CUSTOM_NAME, Component.literal("Fetus"));
            CompoundTag data = mob.getPersistentData().copy();
            CustomData.update(DataComponents.CUSTOM_DATA, fetus, tag -> {
                tag.putString(BRAIN, data.getString(BRAIN).orElse("return home"));
                tag.putString(TRAITS, data.getString(TRAITS).orElse(""));
                tag.putString(OWNER, data.getString(OWNER).orElse(serverPlayer.getUUID().toString()));
            });
            if (!serverPlayer.getInventory().add(fetus)) serverPlayer.drop(fetus, false);
            mob.discard();
            if (!serverPlayer.getAbilities().instabuild) held.shrink(1);
            serverPlayer.sendSystemMessage(Component.literal("The homunculus returns to a transferable fetus. Its soul/program is preserved."));
            return true;
        }
        if (held.is(RequiemItems.EMBRYO) && target instanceof LivingEntity livingTarget) {
            CompoundTag data = readItemData(held);
            String brain = data.getString(BRAIN).orElse("return home");
            livingTarget.getPersistentData().putString(BRAIN, brain);
            livingTarget.getPersistentData().putBoolean("requiem:homunculus_souled", true);
            livingTarget.getPersistentData().putString(TRAITS, data.getString(TRAITS).orElse(""));
            if (!serverPlayer.getAbilities().instabuild) held.shrink(1);
            serverPlayer.sendSystemMessage(Component.literal("The homunculus soul settles into " + livingTarget.getName().getString() + "."));
            return true;
        }
        if (target instanceof Mob mob && isHomunculus(mob) && held.is(Items.BONE)) {
            // The wolf-like body remains normally tamable by Marbas with a bone.
            return false;
        }
        if (shift && target instanceof Mob mob && isHomunculus(mob)) {
            ItemStack body = new ItemStack(RequiemItems.HOMUNCULUS);
            body.set(DataComponents.CUSTOM_NAME, Component.literal("Homunculus Body"));
            CompoundTag data = mob.getPersistentData().copy();
            CustomData.update(DataComponents.CUSTOM_DATA, body, tag -> {
                tag.putString(BRAIN, data.getString(BRAIN).orElse("return home"));
                tag.putString(TRAITS, data.getString(TRAITS).orElse(""));
                tag.putBoolean(BERSERK, data.getBoolean(BERSERK).orElse(false));
            });
            if (!serverPlayer.getInventory().add(body)) serverPlayer.drop(body, false);
            mob.discard();
            serverPlayer.sendSystemMessage(Component.literal("Homunculus collected as an item. Place it in a water cauldron to regrow it."));
            return true;
        }
        return false;
    }

    public static void applyBrainProgram(ServerPlayer player, int entityId, String program) {
        Entity entity = player.level().getEntity(entityId);
        if (!(entity instanceof Mob mob) || !isHomunculus(mob) || mob.distanceTo(player) > 12.0) {
            player.sendSystemMessage(Component.literal("The selected homunculus is no longer nearby."));
            return;
        }
        String safe = program == null ? "" : program.trim();
        if (safe.length() > 1024) safe = safe.substring(0, 1024);
        mob.getPersistentData().putString(BRAIN, safe.isBlank() ? "return home" : safe);
        mob.getPersistentData().putInt(NODE, 0);
        int damage = Math.min(10, player.getPersistentData().getInt("requiem:marbas_brain_damage").orElse(0) + 1);
        player.getPersistentData().putInt("requiem:marbas_brain_damage", damage);
        player.addEffect(new net.minecraft.world.effect.MobEffectInstance(
            ladysnake.requiem.common.entity.effect.RequiemStatusEffects.BRAIN_DAMAGE, 1200, damage - 1, false, false, false));
        player.sendSystemMessage(Component.literal("The homunculus brain/soul has been rewritten. You feel the process strain your own mind."));
    }

    /** Counts completed nights of actual sleep, rather than merely clicking a bed. */
    public static void onPlayerTick(ServerPlayer player) {
        CompoundTag data = player.getPersistentData();
        long now = player.level().getGameTime();
        boolean wasSleeping = data.getBoolean("requiem:marbas_was_sleeping").orElse(false);
        if (player.isSleeping()) {
            if (!wasSleeping) {
                data.putBoolean("requiem:marbas_was_sleeping", true);
                data.putLong("requiem:marbas_sleep_started", now);
            }
        } else if (wasSleeping) {
            long started = data.getLong("requiem:marbas_sleep_started").orElse(now);
            data.remove("requiem:marbas_was_sleeping");
            data.remove("requiem:marbas_sleep_started");
            if (now - started >= 100L) {
                int count = data.getInt("requiem:marbas_sleep_count").orElse(0) + 1;
                data.putInt("requiem:marbas_sleep_count", count);
                if (isMarbas(player)) {
                    player.sendSystemMessage(Component.literal("A completed night's sleep has settled your homunculus research (" + count + "/2 nights)."));
                }
            }
        }
    }

    public static void tick(ServerLevel level, BlockPos center) {
        long now = level.getGameTime();
        AABB activeArea = new AABB(center.getX() - 128.0, level.getMinY(), center.getZ() - 128.0,
            center.getX() + 128.0, level.getMaxY(), center.getZ() + 128.0);
        for (Mob mob : level.getEntitiesOfClass(Mob.class, activeArea, MarbasAbilitySystem::isHomunculus)) {
            try {
                if (mob.getPersistentData().getLong("requiem:homunculus_last_tick").orElse(Long.MIN_VALUE) == now) continue;
                mob.getPersistentData().putLong("requiem:homunculus_last_tick", now);
                int mentalLevel = mob.getPersistentData().getBoolean(BERSERK).orElse(false) ? 10 : 1;
                mob.addEffect(new net.minecraft.world.effect.MobEffectInstance(
                    ladysnake.requiem.common.entity.effect.RequiemStatusEffects.HOMUNCULUS_MENTAL_HEALTH,
                    40, mentalLevel - 1, false, false, false));
                applyInheritedTraits(level, mob, now);
                if (mob.getPersistentData().getBoolean(BERSERK).orElse(false)) tickBerserk(level, mob, now);
                else runBrain(level, mob, now);
            } catch (RuntimeException ignored) {
                // Bad user-authored node text must never crash the server tick.
            }
        }
    }

    private static boolean isHomunculus(Mob mob) {
        return mob.getPersistentData().getBoolean(HOMUNCULUS).orElse(false);
    }

    private static void applyInheritedTraits(ServerLevel level, Mob mob, long now) {
        String traits = mob.getPersistentData().getString(TRAITS).orElse("").toLowerCase(Locale.ROOT);
        if (traits.contains("fire_resistance")) mob.addEffect(new net.minecraft.world.effect.MobEffectInstance(net.minecraft.world.effect.MobEffects.FIRE_RESISTANCE, 40, 0, false, false, false));
        LivingEntity target = mob.getTarget();
        if (target == null || !target.isAlive() || target == mob) return;
        if (traits.contains("fire")) target.igniteForSeconds(3.0F);
        if (traits.contains("wither")) target.addEffect(new net.minecraft.world.effect.MobEffectInstance(net.minecraft.world.effect.MobEffects.WITHER, 60, 0, false, false, true));
        if (traits.contains("explode") && mob.distanceToSqr(target) < 5.0 && now % 20 == 0
                && mob.getPersistentData().getLong("requiem:homunculus_trait_explosion_cooldown").orElse(0L) <= now) {
            for (LivingEntity victim : level.getEntitiesOfClass(LivingEntity.class, mob.getBoundingBox().inflate(3.5), e -> e != mob && e.isAlive())) {
                victim.hurt(level.damageSources().explosion(mob, mob), 12.0F);
            }
            level.sendParticles(net.minecraft.core.particles.ParticleTypes.EXPLOSION, mob.getX(), mob.getY() + 0.8, mob.getZ(), 1, 0, 0, 0, 0);
            mob.getPersistentData().putLong("requiem:homunculus_trait_explosion_cooldown", now + 200L);
        }
    }

    private static void runBrain(ServerLevel level, Mob mob, long now) {
        String program = mob.getPersistentData().getString(BRAIN).orElse("return home");
        String[] nodes = program.split(";");
        if (nodes.length == 0) return;
        int node = Math.max(0, Math.min(nodes.length - 1, mob.getPersistentData().getInt(NODE).orElse(0)));
        String command = nodes[node].trim().toLowerCase(Locale.ROOT);
        if (command.isBlank()) { nextNode(mob, nodes.length); return; }
        if (command.startsWith("goto ")) {
            int[] xyz = parseXYZ(command.substring(5));
            if (xyz == null) { nextNode(mob, nodes.length); return; }
            mob.getNavigation().moveTo(xyz[0] + 0.5, xyz[1], xyz[2] + 0.5, 1.05);
            if (mob.distanceToSqr(xyz[0] + 0.5, xyz[1], xyz[2] + 0.5) < 4.0) nextNode(mob, nodes.length);
            return;
        }
        if (command.equals("return home") || command.equals("home")) {
            int[] xyz = parseXYZ(mob.getPersistentData().getString(HOME).orElse("0 64 0"));
            if (xyz == null) { nextNode(mob, nodes.length); return; }
            mob.getNavigation().moveTo(xyz[0] + 0.5, xyz[1], xyz[2] + 0.5, 1.0);
            if (mob.distanceToSqr(xyz[0] + 0.5, xyz[1], xyz[2] + 0.5) < 4.0) nextNode(mob, nodes.length);
            return;
        }
        if (command.startsWith("find item")) {
            String filter = command.contains(":") ? command.substring(command.indexOf(':') + 1).trim() : "";
            ItemEntity item = level.getEntitiesOfClass(ItemEntity.class, mob.getBoundingBox().inflate(18.0), e -> !e.getItem().isEmpty()
                && (filter.isBlank() || BuiltInRegistries.ITEM.getKey(e.getItem().getItem()).toString().equalsIgnoreCase(filter)
                    || e.getItem().getHoverName().getString().equalsIgnoreCase(filter))).stream()
                .min((a, b) -> Double.compare(a.distanceToSqr(mob), b.distanceToSqr(mob))).orElse(null);
            if (item == null) { mob.getNavigation().stop(); return; }
            mob.getPersistentData().putInt(TARGET_ID, item.getId());
            mob.getNavigation().moveTo(item, 1.1);
            nextNode(mob, nodes.length);
            return;
        }
        if (command.equals("take item") || command.equals("take")) {
            Entity targetItem = level.getEntity(mob.getPersistentData().getInt(TARGET_ID).orElse(-1));
            if (!(targetItem instanceof ItemEntity item) || item.getItem().isEmpty()) { nextNode(mob, nodes.length); return; }
            if (mob.distanceToSqr(item) >= 2.25) { mob.getNavigation().moveTo(item, 1.1); return; }
            ItemStack held = mob.getItemBySlot(EquipmentSlot.MAINHAND);
            if (!held.isEmpty()) mob.spawnAtLocation(level, held.copy());
            mob.setItemSlot(EquipmentSlot.MAINHAND, item.getItem().copy());
            item.discard();
            mob.getNavigation().stop();
            nextNode(mob, nodes.length);
            return;
        }
        if (command.equals("drop item") || command.equals("drop")) {
            ItemStack held = mob.getItemBySlot(EquipmentSlot.MAINHAND);
            if (!held.isEmpty()) {
                mob.spawnAtLocation(level, held.copy());
                mob.setItemSlot(EquipmentSlot.MAINHAND, ItemStack.EMPTY);
            }
            nextNode(mob, nodes.length);
            return;
        }
        if (command.equals("store chest") || command.startsWith("store chest")) {
            ItemStack held = mob.getItemBySlot(EquipmentSlot.MAINHAND);
            if (!held.isEmpty()) {
                BlockPos origin = mob.blockPosition();
                ItemStack remaining = held.copy();
                for (BlockPos pos : BlockPos.betweenClosed(origin.offset(-3, -2, -3), origin.offset(3, 2, 3))) {
                    BlockEntity be = level.getBlockEntity(pos);
                    if (be instanceof Container container && !remaining.isEmpty()) remaining = insertIntoContainer(container, remaining);
                    if (remaining.isEmpty()) break;
                }
                mob.setItemSlot(EquipmentSlot.MAINHAND, remaining);
                if (!remaining.isEmpty()) mob.getNavigation().stop();
            }
            nextNode(mob, nodes.length);
            return;
        }
        if (command.startsWith("find entity")) {
            String targetName = command.contains(":") ? command.substring(command.indexOf(':') + 1).trim() : "";
            LivingEntity target = level.getEntitiesOfClass(LivingEntity.class, mob.getBoundingBox().inflate(24.0), e -> e != mob && !e.isDeadOrDying()
                && (targetName.isBlank() || e.getName().getString().equalsIgnoreCase(targetName))).stream()
                .min((a, b) -> Double.compare(a.distanceToSqr(mob), b.distanceToSqr(mob))).orElse(null);
            if (target == null) { mob.getNavigation().stop(); return; }
            mob.getPersistentData().putInt(TARGET_ID, target.getId());
            mob.getNavigation().moveTo(target, 1.1);
            nextNode(mob, nodes.length);
            return;
        }
        if (command.equals("kill entity") || command.equals("kill")) {
            Entity target = level.getEntity(mob.getPersistentData().getInt(TARGET_ID).orElse(-1));
            if (target instanceof LivingEntity living && living.isAlive()) {
                mob.setTarget(living);
                mob.getNavigation().moveTo(living, 1.15);
                if (mob.distanceToSqr(living) < 3.0) living.hurt(level.damageSources().mobAttack(mob), 6.0F);
            } else nextNode(mob, nodes.length);
            return;
        }
        if (command.equals("wait") || command.equals("guard")) { mob.getNavigation().stop(); return; }
        nextNode(mob, nodes.length);
    }

    private static int[] parseXYZ(String text) {
        String[] p = text.trim().split("\\s+");
        if (p.length != 3) return null;
        try { return new int[] {Integer.parseInt(p[0]), Integer.parseInt(p[1]), Integer.parseInt(p[2])}; }
        catch (NumberFormatException ignored) { return null; }
    }

    /** Inserts a stack into the first empty container slots using the 26.2 Container API.
     * Any overflow remains in the homunculus hand instead of being silently discarded.
     */
    private static ItemStack insertIntoContainer(Container container, ItemStack stack) {
        if (stack.isEmpty()) return ItemStack.EMPTY;
        ItemStack remaining = stack.copy();
        boolean changed = false;
        for (int slot = 0; slot < container.getContainerSize() && !remaining.isEmpty(); slot++) {
            if (!container.canPlaceItem(slot, remaining)) continue;
            ItemStack existing = container.getItem(slot);
            if (existing.isEmpty()) {
                int movedCount = Math.min(remaining.getCount(), container.getMaxStackSize(remaining));
                ItemStack moved = remaining.copy();
                moved.setCount(movedCount);
                container.setItem(slot, moved);
                remaining.shrink(movedCount);
                changed = true;
            } else if (ItemStack.isSameItemSameComponents(existing, remaining)) {
                int maximum = Math.min(container.getMaxStackSize(remaining), existing.getMaxStackSize());
                int capacity = maximum - existing.getCount();
                if (capacity > 0) {
                    int movedCount = Math.min(capacity, remaining.getCount());
                    existing.grow(movedCount);
                    remaining.shrink(movedCount);
                    changed = true;
                }
            }
        }
        if (changed) container.setChanged();
        return remaining;
    }

    private static void nextNode(Mob mob, int nodeCount) {
        int current = mob.getPersistentData().getInt(NODE).orElse(0);
        mob.getPersistentData().putInt(NODE, (current + 1) % Math.max(1, nodeCount));
    }

    private static void tickBerserk(ServerLevel level, Mob mob, long now) {
        mob.setInvulnerable(true);
        if (mob.isInLava()) {
            mob.getPersistentData().putLong(STUN_UNTIL, now + 2L);
            mob.setGlowingTag(true);
            mob.addEffect(new net.minecraft.world.effect.MobEffectInstance(net.minecraft.world.effect.MobEffects.SLOWNESS, 5, 5, false, false, false));
            Vec3 v = mob.getDeltaMovement();
            mob.setDeltaMovement(v.x + (mob.getRandom().nextDouble() - 0.5) * 0.15, v.y + (mob.getRandom().nextDouble() - 0.5) * 0.1, v.z + (mob.getRandom().nextDouble() - 0.5) * 0.15);
            return;
        }
        mob.setGlowingTag(false);
        if (now < mob.getPersistentData().getLong(STUN_UNTIL).orElse(0L)) {
            mob.getNavigation().stop(); mob.setTarget(null); return;
        }
        if (now < mob.getPersistentData().getLong(FED_UNTIL).orElse(0L)) {
            mob.getNavigation().stop(); mob.setTarget(null); return;
        }
        LivingEntity target = level.getEntitiesOfClass(LivingEntity.class, mob.getBoundingBox().inflate(28.0), e -> e != mob && e.isAlive()
            && !(e instanceof ServerPlayer p && (p.isCreative() || p.isSpectator()))).stream()
            .min((a, b) -> Double.compare(a.distanceToSqr(mob), b.distanceToSqr(mob))).orElse(null);
        if (target == null) return;
        var speed = mob.getAttribute(Attributes.MOVEMENT_SPEED);
        if (speed != null) speed.setBaseValue(target instanceof Player p && p.isSprinting() ? 0.13 : 0.10);
        var attack = mob.getAttribute(Attributes.ATTACK_DAMAGE);
        if (attack != null) attack.setBaseValue(20.0);
        mob.setTarget(target);
        mob.getNavigation().moveTo(target, 1.0);
        if (mob.distanceToSqr(target) < 3.1 && now % 10 == 0) {
            target.hurt(level.damageSources().mobAttack(mob), 20.0F);
            mob.getPersistentData().putLong(FED_UNTIL, now + 1200L);
        }
    }

    public static boolean onBerserkDamage(LivingIncomingDamageEvent event) {
        if (!(event.getEntity() instanceof Mob mob) || !mob.getPersistentData().getBoolean(BERSERK).orElse(false)) return false;
        event.setCanceled(true);
        mob.getPersistentData().putLong(STUN_UNTIL, mob.level().getGameTime() + 30L);
        mob.getNavigation().stop();
        mob.setTarget(null);
        return true;
    }

    public static boolean onAttackEntity(Player attacker, Entity target) {
        if (target instanceof Mob mob && mob.getPersistentData().getBoolean(BERSERK).orElse(false)) {
            mob.getPersistentData().putLong(STUN_UNTIL, mob.level().getGameTime() + 30L);
            mob.getNavigation().stop();
            mob.setTarget(null);
            attacker.sendSystemMessage(Component.literal("The Suffering Head's creature staggers, but cannot be killed."));
            return true;
        }
        return false;
    }

    private static boolean isMobHead(ItemStack stack) {
        return stack.is(Items.ZOMBIE_HEAD) || stack.is(Items.SKELETON_SKULL) || stack.is(Items.WITHER_SKELETON_SKULL)
            || stack.is(Items.CREEPER_HEAD) || stack.is(Items.PIGLIN_HEAD) || stack.is(Items.DRAGON_HEAD) || stack.is(Items.PLAYER_HEAD);
    }

    private static String traitsForHead(ItemStack stack) {
        if (stack.is(Items.CREEPER_HEAD)) return "explode; health";
        if (stack.is(Items.PIGLIN_HEAD)) return "trade_gold; health";
        if (stack.is(Items.WITHER_SKELETON_SKULL)) return "wither; health";
        if (stack.is(Items.SKELETON_SKULL)) return "ranged; health";
        if (stack.is(Items.ZOMBIE_HEAD)) return "health; fire_resistance";
        if (stack.is(Items.DRAGON_HEAD)) return "fire; health";
        return "humanlike; health";
    }
}
