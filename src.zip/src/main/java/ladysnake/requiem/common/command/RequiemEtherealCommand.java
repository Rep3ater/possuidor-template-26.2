/*
 * Requiem
 * Copyright (C) 2017-2023 Ladysnake
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses>.
 *
 * Linking this mod statically or dynamically with other
 * modules is making a combined work based on this mod.
 * Thus, the terms and conditions of the GNU General Public License cover the whole combination.
 *
 * In addition, as a special exception, the copyright holders of
 * this mod give you permission to combine this mod
 * with free software programs or libraries that are released under the GNU LGPL
 * and with code included in the standard release of Minecraft under All Rights Reserved (or
 * modified versions of such code, with unchanged license).
 * You may copy and distribute such a system following the terms of the GNU GPL for this mod
 * and the licenses of the other code concerned.
 *
 * Note that people who make modified versions of this mod are not obligated to grant
 * this special exception for their modified versions; it is their choice whether to do so.
 * The GNU General Public License gives permission to release a modified version without this exception;
 * this exception also makes it possible to release a modified version which carries forward this exception.
 */
package ladysnake.requiem.common.command;

import com.mojang.brigadier.arguments.BoolArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import ladysnake.requiem.api.v1.remnant.RemnantComponent;

import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.network.chat.Component;
import net.minecraft.world.level.gamerules.GameRules;

import java.util.Collection;
import java.util.Collections;

import static net.minecraft.commands.Commands.argument;
import static net.minecraft.commands.Commands.literal;

public final class RequiemEtherealCommand {
    public static final String ETHEREAL_SUBCOMMAND = "vagrant";

    static LiteralArgumentBuilder<CommandSourceStack> etherealSubcommand() {
        return literal(ETHEREAL_SUBCOMMAND)
            .requires(RequiemCommand.permission("vagrant.query.self").or(RequiemCommand.permission("vagrant.set.self")))
            // requiem vagrant query [player]
            .then(literal("query")
                .requires(RequiemCommand.permission("vagrant.query.self"))
                .executes(context -> queryEthereal(context.getSource(), context.getSource().getPlayer()))
                .then(argument("target", EntityArgument.player())
                    .requires(RequiemCommand.permission("vagrant.query"))
                    .executes(context -> queryEthereal(context.getSource(), EntityArgument.getPlayer(context, "target")))
                )
            )
            // requiem vagrant set <true|false> [player]
            .then(literal("set")
                .requires(RequiemCommand.permission("vagrant.set.self"))
                .then(argument("ethereal", BoolArgumentType.bool())
                    .executes(context -> setEthereal(context.getSource(), Collections.singleton(context.getSource().getPlayer()), BoolArgumentType.getBool(context, "ethereal")))
                    .then(argument("target", EntityArgument.players())
                        .requires(RequiemCommand.permission("vagrant.set"))
                        .executes(context -> setEthereal(context.getSource(), EntityArgument.getPlayers(context, "target"), BoolArgumentType.getBool(context, "ethereal")))
                    )
                )
            );
    }

    private static int queryEthereal(CommandSourceStack source, ServerPlayer player) {
        boolean remnant = RemnantComponent.get(player).isVagrant();
        Component remnantState = Component.translatable("requiem:" + (remnant ? "ethereal" : "not_ethereal"));
        source.sendSuccess(() -> Component.translatable("requiem:commands.query.success." + (source.getEntity() == player ? "self" : "other"), remnantState), true);
        return remnant ? 1 : 0;
    }

    private static int setEthereal(CommandSourceStack source, Collection<ServerPlayer> players, boolean ethereal) {
        int count = 0;
        for (ServerPlayer player : players) {
            if (RemnantComponent.get(player).isVagrant() != ethereal) {
                if (!isRemnant(player)) {
                    source.sendFailure(Component.translatable("requiem:commands.ethereal.set.fail.mortal", player.getDisplayName()));
                    continue;
                }
                if (!RemnantComponent.get(player).setVagrant(ethereal)) {
                    source.sendFailure(Component.translatable("requiem:commands.ethereal.set.fail", player.getDisplayName()));
                    continue;
                }
                sendSetEtherealFeedback(source, player, ethereal);
                ++count;
            }
        }
        return count;
    }

    private static void sendSetEtherealFeedback(CommandSourceStack source, ServerPlayer player, boolean ethereal) {
        Component name = Component.translatable("requiem:" + (ethereal ? "ethereal" : "not_ethereal"));
        if (source.getEntity() == player) {
            source.sendSuccess(() -> Component.translatable("requiem:commands.ethereal.set.success.self", name), true);
        } else {
            if (source.getLevel().getGameRules().get(GameRules.SEND_COMMAND_FEEDBACK)) {
                player.sendSystemMessage(Component.translatable("requiem:commands.ethereal.set.target", name));
            }

            source.sendSuccess(() -> Component.translatable("requiem:commands.ethereal.set.success.other", player.getDisplayName(), name), true);
        }
    }

    private static boolean isRemnant(ServerPlayer player) {
        return RemnantComponent.get(player).getRemnantType().isDemon();
    }
}
