/*
 * Requiem
 * Copyright (C) 2017-2023 Ladysnake
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses>.
 *
 * Linking this mod statically or dynamically with other
 * modules is making a combined work based on this mod.
 * Thus, the terms and conditions of the GNU General Public License cover the whole combination.
 *
 * In addition, as a special exception, the copyright holders of
 * this mod give you permission to combine this mod
 * with free software programs or libraries that are released under the GNU LGPL
 * and with code included in the standard release of Minecraft under All Rights Reserved (or
 * modified versions of such code, with unchanged license).
 * You may copy and distribute such a system following the terms of the GNU GPL for this mod
 * and the licenses of the other code concerned.
 *
 * Note that people who make modified versions of this mod are not obligated to grant
 * this special exception for their modified versions; it is their choice whether to do so.
 * The GNU General Public License gives permission to release a modified version without this exception;
 * this exception also makes it possible to release a modified version which carries forward this exception.
 */
package ladysnake.requiem.common.item;

import ladysnake.requiem.common.block.RequiemBlocks;
import ladysnake.requiem.common.block.obelisk.InertRunestoneBlock;
import ladysnake.requiem.common.block.obelisk.RunestoneBlock;
import ladysnake.requiem.common.sound.RequiemSoundEvents;
import net.minecraft.advancement.criterion.Criteria;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.ItemUtils;
import net.minecraft.world.item.ItemUsageContext;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundSource;
import net.minecraft.stats.Stats;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.util.UseAction;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.event.GameEvent;

import java.util.Optional;

public class IchorVesselItem extends Item {
    private static final int MAX_USE_TIME = 20;

    private final MobEffectInstance effect;

    public IchorVesselItem(Settings settings, MobEffectInstance effect) {
        super(settings);
        this.effect = effect;
    }

    @Override
    public ItemStack finishUsing(ItemStack stack, Level world, LivingEntity user) {
        Player player = user instanceof Player ? (Player)user : null;
        if (player instanceof ServerPlayer serverPlayer) {
            Criteria.CONSUME_ITEM.trigger(serverPlayer, stack);
        }

        if (!world.isClient) {
            user.addStatusEffect(new MobEffectInstance(this.effect));
        }

        if (player != null) {
            player.incrementStat(Stats.USED.getOrCreateStat(this));
            if (!player.getAbilities().creativeMode) {
                stack.decrement(1);
            }
        }

        if (player == null || !player.getAbilities().creativeMode) {
            if (stack.isEmpty()) {
                return new ItemStack(RequiemItems.EMPTY_SOUL_VESSEL);
            }

            if (player != null) {
                player.getInventory().insertStack(new ItemStack(RequiemItems.EMPTY_SOUL_VESSEL));
            }
        }

        user.emitGameEvent(GameEvent.DRINK);
        return stack;
    }

    @Override
    public int getMaxUseTime(ItemStack stack) {
        return MAX_USE_TIME;
    }

    @Override
    public UseAction getUseAction(ItemStack stack) {
        return UseAction.BOW;
    }

    @Override
    public InteractionResult useOnBlock(ItemUsageContext context) {
        Level world = context.getWorld();
        BlockPos pos = context.getBlockPos();
        ItemStack stack = context.getStack();
        Player player = context.getPlayer();

        InteractionResult<ItemStack> result = useOnBlock(world, pos, stack);
        if (result.getResult().isAccepted()) {
            if (player != null) {
                Item item = stack.getItem();
                player.setStackInHand(context.getHand(), ItemUtils.exchangeStack(stack, player, result.getValue()));
                player.incrementStat(Stats.USED.getOrCreateStat(item));
            }
        }
        return result.getResult();
    }

    public InteractionResult<ItemStack> useOnBlock(Level world, BlockPos pos, ItemStack stack) {
        if (world.getBlockState(pos).isOf(RequiemBlocks.TACHYLITE_RUNESTONE)) {
            if (!world.isClient) {
                Optional<Block> runestone = RunestoneBlock.getByEffect(this.effect.getEffectType());
                if (runestone.isEmpty()) return InteractionResult.fail(stack);

                world.setBlockState(pos, runestone.get().getDefaultState(), Block.NOTIFY_LISTENERS | Block.NOTIFY_NEIGHBORS);
                InertRunestoneBlock.tryActivateObelisk((ServerLevel) world, pos, false);

                world.playSound(null, pos, RequiemSoundEvents.BLOCK_RUNESTONE_CARVE, SoundSource.BLOCKS, 1.0F, 1.0F);
                world.emitGameEvent(null, GameEvent.FLUID_PLACE, pos);
                return InteractionResult.success(new ItemStack(RequiemItems.EMPTY_SOUL_VESSEL), false);
            }

            return InteractionResult.success(stack, true);
        }

        return InteractionResult.pass(stack);
    }

    @Override
    public InteractionResult<ItemStack> use(Level world, Player user, InteractionHand hand) {
        return ItemUtils.consumeHeldItem(world, user, hand);
    }
}
