/*
 * Requiem
 * Copyright (C) 2017-2023 Ladysnake
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses>.
 *
 * Linking this mod statically or dynamically with other
 * modules is making a combined work based on this mod.
 * Thus, the terms and conditions of the GNU General Public License cover the whole combination.
 *
 * In addition, as a special exception, the copyright holders of
 * this mod give you permission to combine this mod
 * with free software programs or libraries that are released under the GNU LGPL
 * and with code included in the standard release of Minecraft under All Rights Reserved (or
 * modified versions of such code, with unchanged license).
 * You may copy and distribute such a system following the terms of the GNU GPL for this mod
 * and the licenses of the other code concerned.
 *
 * Note that people who make modified versions of this mod are not obligated to grant
 * this special exception for their modified versions; it is their choice whether to do so.
 * The GNU General Public License gives permission to release a modified version without this exception;
 * this exception also makes it possible to release a modified version which carries forward this exception.
 */
package ladysnake.requiem.common.possession;

import ladysnake.requiem.api.v1.remnant.RemnantComponent;
import ladysnake.requiem.common.loot.RequiemLootTables;
import ladysnake.requiem.common.particle.RequiemParticleTypes;
import ladysnake.requiem.core.possession.PossessedDataBase;
import net.minecraft.client.MinecraftClient;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.storage.loot.LootTable;
import net.minecraft.world.level.storage.loot.LootContext;
import net.minecraft.world.level.storage.loot.LootContextParameters;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.resources.Identifier;
import net.minecraft.world.level.Level;

public class LootingPossessedData extends PossessedDataBase {
    private boolean previouslyPossessed;

    public LootingPossessedData(Entity holder) {
        super(holder);
    }

    @Override
    public void giftFirstPossessionLoot(Player player) {
        if (!this.previouslyPossessed) {
            this.dropLoot(player);
            this.previouslyPossessed = true;
        }
    }

    @Override
    public void clientTick() {
        if (this.wasConvertedUnderPossession()) {
            Entity camera = MinecraftClient.getInstance().getCameraEntity();
            Level world = holder.world;
            if (camera != null && RemnantComponent.isIncorporeal(camera)) {
                if (world.random.nextFloat() > 0.9f) {
                    for (int i = 0; i < world.random.nextInt(3); i++) {
                        double vx = world.random.nextGaussian() * 0.03D;
                        double vy = world.random.nextGaussian() * 0.03D;
                        double vz = world.random.nextGaussian() * 0.03D;
                        world.addParticle(RequiemParticleTypes.ATTUNED, holder.getParticleX(0.5D), holder.getRandomBodyY(), holder.getParticleZ(0.5D), vx, vy, vz);
                    }
                }
            }
        }
    }

    protected void dropLoot(Player player) {
        Identifier identifier = this.getLootTable();
        ServerLevel world = (ServerLevel) this.holder.world;
        LootTable lootTable = world.getServer().getLootManager().getTable(identifier);
        LootContext.Builder builder = new LootContext.Builder(world)
            .random(world.random)
            .parameter(LootContextParameters.THIS_ENTITY, this.holder)
            .parameter(LootContextParameters.ORIGIN, this.holder.getPos())
            .luck(player.getLuck());
        lootTable.generateLoot(builder.build(RequiemLootTables.POSSESSION), player.getInventory()::offerOrDrop);
    }

    private Identifier getLootTable() {
        Identifier identifier = BuiltInRegistries.ENTITY_TYPE.getId(this.holder.getType());
        return Identifier.fromNamespaceAndPath(identifier.getNamespace(), "requiem/possession/" + identifier.getPath());
    }

    @Override
    protected void onPossessed() {
        this.previouslyPossessed = true;
    }

    @Override
    public void readFromNbt(CompoundTag tag) {
        super.readFromNbt(tag);

        if (tag.contains("previously_possessed")) {
            this.previouslyPossessed = tag.getBoolean("previously_possessed");
        }
    }

    @Override
    public void writeToNbt(CompoundTag tag) {
        super.writeToNbt(tag);

        if (this.previouslyPossessed) {
            tag.putBoolean("previously_possessed", true);
        }
    }
}
