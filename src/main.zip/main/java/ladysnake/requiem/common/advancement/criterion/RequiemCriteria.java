package ladysnake.requiem.common.advancement.criterion;

import ladysnake.requiem.Requiem;
import net.minecraft.advancements.triggers.CriterionTrigger;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;

public class RequiemCriteria {
    public static final OnResurrectCriterion PLAYER_RESURRECTED_AS_ENTITY = register("player_resurrected_as_entity", new OnResurrectCriterion(Requiem.id("player_resurrected_as_entity")));
    public static final OnRemnantChoiceCriterion MADE_REMNANT_CHOICE = register("made_remnant_choice", new OnRemnantChoiceCriterion(Requiem.id("made_remnant_choice")));
    public static final OnPossessionCriterion PLAYER_POSSESSED_ENTITY = register("player_possessed_entity", new OnPossessionCriterion(Requiem.id("player_possessed_entity")));
    public static final OnDeathAfterPossessionCriterion DEATH_AFTER_POSSESSION = register("entity_died_after_possession", new OnDeathAfterPossessionCriterion(Requiem.id("entity_died_after_possession")));
    public static final PossessedHitEntityCriterion POSSESSED_HIT_ENTITY = register("possessed_hit_entity", new PossessedHitEntityCriterion(Requiem.id("possessed_hit_entity")));
    public static final TransformedPossessedCriterion TRANSFORMED_POSSESSED_ENTITY = register("transformed_possessed_entity", new TransformedPossessedCriterion(Requiem.id("transformed_possessed_entity")));
    public static final UsedRequiemTotemCriterion USED_TOTEM = register("used_totem", new UsedRequiemTotemCriterion(Requiem.id("used_totem")));

    private static <T extends CriterionTrigger<?>> T register(String name, T trigger) {
        return Registry.register(BuiltInRegistries.TRIGGER_TYPES, Requiem.id(name), trigger);
    }

    public static void init() {
        // Triggers registered statically
    }
}
