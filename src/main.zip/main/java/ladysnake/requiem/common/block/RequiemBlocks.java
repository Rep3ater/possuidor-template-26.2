package ladysnake.requiem.common.block;

import com.google.common.base.Suppliers;
import ladysnake.requiem.Requiem;
import ladysnake.requiem.api.v1.block.ObeliskRune;
import ladysnake.requiem.api.v1.block.VagrantTargetableBlock;
import ladysnake.requiem.common.block.obelisk.InertRunestoneBlock;
import ladysnake.requiem.common.block.obelisk.ReclamationRunestoneBlock;
import ladysnake.requiem.common.block.obelisk.RiftRunestoneBlock;
import ladysnake.requiem.common.block.obelisk.RunestoneBlock;
import ladysnake.requiem.common.entity.effect.RequiemStatusEffects;
import ladysnake.requiem.common.item.RequiemItems;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.util.valueproviders.UniformInt;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.DropExperienceBlock;
import net.minecraft.world.level.block.RotatedPillarBlock;
import net.minecraft.world.level.block.SlabBlock;
import net.minecraft.world.level.block.StairBlock;
import net.minecraft.world.level.block.state.BlockBehaviour;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.function.Supplier;
import java.util.stream.Stream;

public final class RequiemBlocks {
    private static final Map<Block, BlockRegistration> allBlocks = new LinkedHashMap<>();

    public static final Block TACHYLITE = make(() -> new Block(BlockBehaviour.Properties.ofFullCopy(Blocks.OBSIDIAN)
        .destroyTime(25.0f)
        .explosionResistance(600.0f)
    ), "tachylite/tachylite", CreativeModeTabs.BUILDING_BLOCKS);
    public static final Block CHISELED_TACHYLITE = makeVariant(TACHYLITE, "tachylite/chiseled");
    public static final RotatedPillarBlock CHISELED_TACHYLITE_PILLAR = makePillar(CHISELED_TACHYLITE);
    public static final SlabBlock CHISELED_TACHYLITE_SLAB = makeSlab(CHISELED_TACHYLITE);
    public static final StairBlock CHISELED_TACHYLITE_STAIRS = makeStairs(CHISELED_TACHYLITE);
    public static final SlabBlock TACHYLITE_SLAB = makeSlab(TACHYLITE);
    public static final StairBlock TACHYLITE_STAIRS = makeStairs(TACHYLITE);
    public static final Block SCRAPED_TACHYLITE = makeVariant(TACHYLITE, "tachylite/scraped");
    public static final InertRunestoneBlock TACHYLITE_RUNESTONE = make(() -> new InertRunestoneBlock(BlockBehaviour.Properties.ofFullCopy(TACHYLITE)), "tachylite/runestone", CreativeModeTabs.BUILDING_BLOCKS);
    public static final DropExperienceBlock DERELICT_TACHYLITE = make(() -> new DropExperienceBlock(UniformInt.of(7, 14), BlockBehaviour.Properties.ofFullCopy(TACHYLITE)), "tachylite/derelict", CreativeModeTabs.NATURAL);
    public static final RunestoneBlock RUNIC_TACHYLITE_ATTRITION = makeRunic("attrition", 3);
    public static final RunestoneBlock RUNIC_TACHYLITE_EMANCIPATION = makeRunic("emancipation", 1);
    public static final RunestoneBlock RUNIC_TACHYLITE_PENANCE = makeRunic("penance", 3);
    public static final ReclamationRunestoneBlock RUNIC_TACHYLITE_RECLAMATION = make(() -> new ReclamationRunestoneBlock(BlockBehaviour.Properties.ofFullCopy(TACHYLITE_RUNESTONE), () -> RequiemStatusEffects.RECLAMATION, 1), "tachylite/runic/reclamation", CreativeModeTabs.FUNCTIONAL);
    public static final RiftRunestoneBlock RIFT_RUNE = make(() -> new RiftRunestoneBlock(BlockBehaviour.Properties.ofFullCopy(TACHYLITE_RUNESTONE)), "tachylite/runic/rift", CreativeModeTabs.FUNCTIONAL);

    private static Block makeVariant(Block base, String id) {
        return make(() -> new Block(BlockBehaviour.Properties.ofFullCopy(base)), id, CreativeModeTabs.BUILDING_BLOCKS);
    }

    private static RotatedPillarBlock makePillar(Block base) {
        return make(() -> new RotatedPillarBlock(BlockBehaviour.Properties.ofFullCopy(base)), allBlocks.get(base).name() + "_pillar", CreativeModeTabs.BUILDING_BLOCKS);
    }

    private static StairBlock makeStairs(Block base) {
        return make(() -> new StairBlock(base.defaultBlockState(), BlockBehaviour.Properties.ofFullCopy(base)), allBlocks.get(base).name() + "_stairs", CreativeModeTabs.BUILDING_BLOCKS);
    }

    private static SlabBlock makeSlab(Block base) {
        return make(() -> new SlabBlock(BlockBehaviour.Properties.ofFullCopy(base)), allBlocks.get(base).name() + "_slab", CreativeModeTabs.BUILDING_BLOCKS);
    }

    private static RunestoneBlock makeRunic(String effectName, int maxLevel) {
        return make(() -> new RunestoneBlock(
            BlockBehaviour.Properties.ofFullCopy(TACHYLITE),
            Suppliers.memoize(() -> BuiltInRegistries.MOB_EFFECT.getOptional(Requiem.id(effectName)).orElseThrow()),
            maxLevel
        ), "tachylite/runic/" + effectName, CreativeModeTabs.FUNCTIONAL);
    }

    private static <B extends Block> B make(Supplier<B> factory, String name, CreativeModeTab itemGroup) {
        B ret = factory.get();
        allBlocks.put(ret, new BlockRegistration(name, new BlockRegistration.BlockItemRegistration(itemGroup, BlockItem::new)));
        return ret;
    }

    public static void init() {
        allBlocks.forEach(RequiemBlocks::register);
        InertRunestoneBlock.registerCallbacks();
        VagrantTargetableBlock.LOOKUP.registerForBlocks((world, pos, state, blockEntity, context) -> state.getValue(InertRunestoneBlock.ACTIVATED) ? RIFT_RUNE : null, RIFT_RUNE);
    }

    public static Stream<Map.Entry<Block, Identifier>> streamRunestones() {
        return allBlocks.entrySet().stream().filter(e -> e.getKey() instanceof InertRunestoneBlock).map(e -> Map.entry(e.getKey(), Requiem.id(e.getValue().name())));
    }

    public static void register(Block block, String name, CreativeModeTab itemGroup) {
        register(block, new BlockRegistration(name, new BlockRegistration.BlockItemRegistration(itemGroup, BlockItem::new)));
    }

    private static void register(Block block, BlockRegistration registration) {
        Registry.register(BuiltInRegistries.BLOCK, Requiem.id(registration.name()), block);

        BlockRegistration.BlockItemRegistration blockItemRegistration = registration.blockItemRegistration();
        if (blockItemRegistration != null) {
            BlockItem item = blockItemRegistration.blockItemFactory().apply(block, new Item.Properties());
            item.registerBlocks(Item.BY_BLOCK, item);
            RequiemItems.registerItem(item, registration.name(), blockItemRegistration.group());
        }

        if (block instanceof ObeliskRune rune) {
            ObeliskRune.LOOKUP.registerForBlocks((world, pos, state, blockEntity, context) -> rune, block);
        }
    }
}
