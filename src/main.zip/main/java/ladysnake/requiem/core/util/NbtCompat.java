/*
 * Requiem
 * Copyright (C) 2017-2023 Ladysnake
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU License
 * along with this program. If not, see <https://www.gnu.org/licenses>.
 *
 * Linking this mod statically or dynamically with other
 * modules is making a combined work based on this mod.
 * Thus, the terms and conditions of the GNU General Public License cover the whole combination.
 *
 * In addition, as a special exception, the copyright holders of
 * this mod give you permission to combine this mod
 * with free software programs or libraries that are released under the GNU LGPL
 * and with code included in the standard release of Minecraft under All Rights Reserved (or
 * modified versions of such code, with unchanged license).
 * You may copy and distribute such a system following the terms of the GNU GPL for this mod
 * and the licenses of the other code concerned.
 *
 * Note that people who make modified versions of this mod are not obligated to grant
 * this special exception for their modified versions; it is their choice whether to do so.
 * The GNU General Public License gives permission to release a modified version without this exception;
 * this exception also makes it possible to release a modified version which carries forward this exception.
 */
package ladysnake.requiem.core.util;

import net.minecraft.core.UUIDUtil;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;

import java.util.Optional;
import java.util.UUID;

/**
 * Helpers bridging the pre-1.21.5 {@link CompoundTag} accessors used all over Requiem
 * with the Optional-based API of Minecraft 26.x. UUIDs keep their historical on-disk format (int array).
 */
public final class NbtCompat {
    private NbtCompat() { throw new AssertionError(); }

    public static void putUuid(CompoundTag tag, String key, UUID uuid) {
        tag.store(key, UUIDUtil.CODEC, uuid);
    }

    public static Optional<UUID> getUuid(CompoundTag tag, String key) {
        return tag.read(key, UUIDUtil.CODEC);
    }

    public static boolean containsUuid(CompoundTag tag, String key) {
        return getUuid(tag, key).isPresent();
    }

    public static boolean isList(CompoundTag tag, String key) {
        return tag.get(key) instanceof ListTag;
    }

    public static boolean isCompound(CompoundTag tag, String key) {
        return tag.get(key) instanceof CompoundTag;
    }

    public static boolean isString(CompoundTag tag, String key) {
        return tag.get(key) != null && tag.get(key).getId() == Tag.TAG_STRING;
    }
}