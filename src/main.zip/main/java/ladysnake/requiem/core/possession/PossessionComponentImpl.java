/*
 * Requiem
 * Copyright (C) 2017-2023 Ladysnake
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU License
 * along with this program. If not, see <https://www.gnu.org/licenses>.
 *
 * Linking this mod statically or dynamically with other
 * modules is making a combined work based on this mod.
 * Thus, the terms and conditions of the GNU General Public License cover the whole combination.
 *
 * In addition, as a special exception, the copyright holders of
 * this mod give you permission to combine this mod
 * with free software programs or libraries that are released under the GNU LGPL
 * and with code included in the standard release of Minecraft under All Rights Reserved (or
 * modified versions of such code, with unchanged license).
 * You may copy and distribute such a system following the terms of the GNU GPL for this mod
 * and the licenses of the other code concerned.
 *
 * Note that people who make modified versions of this mod are not obligated to grant
 * this special exception for their modified versions; it is their choice whether to do so.
 * The GNU General Public License gives permission to release a modified version without this exception;
 * this exception also makes it possible to release a modified version which carries forward this exception.
 */
package ladysnake.requiem.core.possession;

import com.demonwav.mcdev.annotations.CheckEnv;
import com.demonwav.mcdev.annotations.Env;
import ladysnake.requiem.api.v1.entity.MovementAlterer;
import ladysnake.requiem.api.v1.entity.MovementRegistry;
import ladysnake.requiem.api.v1.event.requiem.PossessionEvents;
import ladysnake.requiem.api.v1.event.requiem.PossessionStartCallback;
import ladysnake.requiem.api.v1.event.requiem.PossessionStateChangeCallback;
import ladysnake.requiem.api.v1.possession.Possessable;
import ladysnake.requiem.api.v1.possession.PossessedData;
import ladysnake.requiem.api.v1.possession.PossessionComponent;
import ladysnake.requiem.api.v1.remnant.AttritionFocus;
import ladysnake.requiem.api.v1.remnant.RemnantComponent;
import ladysnake.requiem.api.v1.remnant.SoulbindingRegistry;
import ladysnake.requiem.core.RequiemCore;
import ladysnake.requiem.core.RequiemCoreNetworking;
import ladysnake.requiem.core.mixin.access.LivingEntityAccessor;
import ladysnake.requiem.core.movement.SerializableMovementConfig;
import ladysnake.requiem.core.tag.RequiemCoreTags;
import ladysnake.requiem.core.util.InventoryHelper;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.protocol.game.ClientboundUpdateAttributesPacket;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.RandomSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;

import javax.annotation.CheckForNull;
import javax.annotation.Nullable;
import java.util.UUID;

public final class PossessionComponentImpl implements PossessionComponent {
    private final Player player;
    @Nullable
    private Mob possessed;
    private int conversionTimer;

    public PossessionComponentImpl(Player player) {
        this.player = player;
    }

    private boolean isReadyForPossession() {
        return player.level().isClientSide() || (!player.isSpectator() && RemnantComponent.get(this.player).isIncorporeal());
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public boolean startPossessing(final Mob host, boolean simulate) {
        // Check that the player can initiate possession
        if (!isReadyForPossession()) {
            return false;
        }

        PossessionStartCallback.Result result = PossessionStartCallback.EVENT.invoker().onPossessionAttempted(host, this.player, simulate);
        if (result != PossessionStartCallback.Result.ALLOW) {
            return result.isSuccess();
        }

        Possessable possessable = (Possessable) host;
        // Check that the mob can be possessed
        if (!possessable.canBePossessedBy(player)) {
            return false;
        }
        if (!simulate) {
            startPossessing0(host, possessable);
        }
        return true;
    }

    private void startPossessing0(Mob host, Possessable possessable) {
        possessable.setPossessor(null);
        // Transfer inventory and mount
        if (!player.level().isClientSide()) {
            if (host.getType().builtInRegistryHolder().is(RequiemCoreTags.Entity.INVENTORY_CARRIERS)) {
                PossessedData.KEY.get(host).moveItems(player.getInventory(), false);
            }
            if (host.getType().builtInRegistryHolder().is(RequiemCoreTags.Entity.ITEM_USERS)) {
                InventoryHelper.transferEquipment(host, player);
            }
            for (MobEffectInstance effect : player.getActiveEffects()) {
                if (SoulbindingRegistry.instance().isSoulbound(effect.getEffect().value())) {
                    host.addEffect(new MobEffectInstance(effect));
                }
            }
            for (MobEffectInstance effect : host.getActiveEffects()) {
                player.addEffect(new MobEffectInstance(effect));
            }
            Entity ridden = ((Entity) possessable).getVehicle();
            if (ridden != null) {
                ((Mob) possessable).stopRiding();
                player.startRiding(ridden);
            }
            if (host.getType().builtInRegistryHolder().is(RequiemCoreTags.Entity.EATERS)) {
                CompoundTag hungerData = PossessedData.KEY.get(host).getHungerData();
                player.getFoodData().setFoodLevel(hungerData.getIntOr("foodLevel", 20));
                player.getFoodData().setSaturation(hungerData.getFloatOr("foodSaturationLevel", 5.0F));
            }

            host.setTarget(null);
        }
        // Actually set the possessed entity
        this.possessed = host;
        possessable.setPossessor(this.player);
        PossessionComponent.KEY.sync(this.player);
        // Update some attributes
        this.player.copyPosition(host);
        this.player.setYRot(host.getYRot());
        this.player.setXRot(host.getXRot());
        this.player.refreshDimensions(); // update size
        MovementAlterer.get(this.player).setConfig(MovementRegistry.get(this.player.level()).getEntityMovementConfig(host.getType()));

        // Make the mob react a bit
        host.playAmbientSound();

        //Set persistent
        host.setPersistenceRequired();

        // Fire event
        PossessionStateChangeCallback.EVENT.invoker().onPossessionStateChange(this.player, host);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void stopPossessing() {
        this.stopPossessing(!this.player.isCreative());
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void stopPossessing(boolean transfer) {
        LivingEntity host = this.getHost();
        if (host != null) {
            this.resetState();
            ((Possessable) host).setPossessor(null);

            if (player instanceof ServerPlayer serverPlayer) {
                Entity ridden = player.getVehicle();
                if (ridden != null) {
                    player.stopRiding();
                    host.startRiding(ridden);
                }

                if (transfer) {
                    dropEquipment(host, serverPlayer);
                }

                if (host.getType().builtInRegistryHolder().is(RequiemCoreTags.Entity.EATERS)) {
                    CompoundTag hungerData = PossessedData.KEY.get(host).getHungerData();
                    hungerData.putInt("foodLevel", player.getFoodData().getFoodLevel());
                    hungerData.putFloat("foodSaturationLevel", player.getFoodData().getSaturationLevel());
                }

                // move soulbound effects from the host to the soul
                // careful with ConcurrentModificationException
                for (MobEffectInstance effect : host.getActiveEffects().toArray(new MobEffectInstance[0])) {
                    if (SoulbindingRegistry.instance().isSoulbound(effect.getEffect().value())) {
                        host.removeEffect(effect.getEffect());
                        player.addEffect(new MobEffectInstance(effect));
                    }
                }

                host.setSprinting(false);
            }
        }
    }

    public static void dropEquipment(LivingEntity possessed, ServerPlayer player) {
        if (PossessionEvents.INVENTORY_TRANSFER_CHECK.invoker().shouldTransfer(player, possessed).get()) {
            if (possessed.getType().builtInRegistryHolder().is(RequiemCoreTags.Entity.ITEM_USERS)) {
                InventoryHelper.transferEquipment(player, possessed);
            }
            if (possessed.getType().builtInRegistryHolder().is(RequiemCoreTags.Entity.INVENTORY_CARRIERS)) {
                PossessedData.KEY.get(possessed).moveItems(player.getInventory(), true);
            }
            if (player.level() instanceof ServerLevel serverLevel) {
                ((LivingEntityAccessor) player).requiem$invokeDropEquipment(serverLevel);
            }
        }
        player.removeAllEffects();
        if (player.level().getLevelData().isHardcore()) {
            AttritionFocus.KEY.get(possessed).applyAttrition(player);
        }
        PossessionEvents.DISSOCIATION_CLEANUP.invoker().cleanUpAfterDissociation(player, possessed);
    }

    @Override
    public void writeSyncPacket(RegistryFriendlyByteBuf buf, ServerPlayer recipient) {
        buf.writeInt(this.possessed == null ? -1 : this.possessed.getId());
    }

    @Override
    public void applySyncPacket(RegistryFriendlyByteBuf buf) {
        int possessedId = buf.readInt();
        Entity entity = player.level().getEntity(possessedId);

        if (entity instanceof Mob mob) {
            this.startPossessing(mob);
            updateCamera(this.player, entity);
        } else {
            this.stopPossessing();
            updateCamera(this.player, this.player);
        }
    }

    @CheckEnv(Env.CLIENT)
    private static void updateCamera(Player player, Entity cameraEntity) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.options.getCameraType().isFirstPerson() && player == mc.player) {
            mc.gameRenderer.checkEntityPostEffect(cameraEntity);
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public @CheckForNull Mob getHost() {
        if (!this.isPossessionOngoing()) {
            return null;
        }

        if (this.possessed.isRemoved()) {
            UUID possessedUuid = this.possessed.getUUID();
            RequiemCore.LOGGER.debug("{}: this player's possessed entity has disappeared", this.player);
            this.resetState();
            // Attempt to find an equivalent entity using the UUID
            if (this.player.level() instanceof ServerLevel serverLevel) {
                Entity host = serverLevel.getEntity(possessedUuid);
                if (host instanceof Mob mob && host instanceof Possessable) {
                    this.startPossessing(mob);
                }
            }
        }
        return this.possessed;
    }

    private void resetState() {
        this.possessed = null;
        this.conversionTimer = 0;
        MovementAlterer.get(this.player).setConfig(RemnantComponent.get(this.player).isVagrant() ? SerializableMovementConfig.SOUL : null);
        this.player.refreshDimensions(); // update size
        this.player.setAirSupply(this.player.getMaxAirSupply());
        PossessionComponent.KEY.sync(this.player);
        PossessionStateChangeCallback.EVENT.invoker().onPossessionStateChange(this.player, null);
        RequiemCoreNetworking.sendToAllTrackingIncluding(player, new ClientboundUpdateAttributesPacket(player.getId(), player.getAttributes().getSyncableAttributes()));
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public boolean isPossessionOngoing() {
        return this.possessed != null;
    }

    @Override
    public boolean canBeCured(ItemStack cure) {
        Mob possessedEntity = this.getHost();
        return possessedEntity != null
            && cure.is(RequiemCoreTags.Item.UNDEAD_CURES)
            && possessedEntity.hasEffect(MobEffects.WEAKNESS)
            && RemnantComponent.get(this.player).canCurePossessed(possessedEntity);
    }

    @Override
    public void startCuring() {
        if (!this.player.level().isClientSide()) {
            RandomSource rand = this.player.getRandom();
            this.conversionTimer = rand.nextInt(1201) + 2400;  // a bit shorter than villager
            this.player.removeEffect(MobEffects.WEAKNESS);
            this.player.addEffect(new MobEffectInstance(MobEffects.STRENGTH, conversionTimer, 0));
            this.player.level().playSound(null, this.player.getX() + 0.5D, this.player.getY() + 0.5D, this.player.getZ() + 0.5D, SoundEvents.ZOMBIE_VILLAGER_CURE, this.player.getSoundSource(), 1.0F + rand.nextFloat(), rand.nextFloat() * 0.7F + 0.3F);
        }
    }

    @Override
    public boolean isCuring() {
        return this.conversionTimer > 0;
    }

    @Override
    public void serverTick() {
        if (this.player.isSpectator()) {
            this.stopPossessing();
        }
        if (this.isCuring()) {
            if (!this.isPossessionOngoing()) this.conversionTimer = 0;
            else this.conversionTimer--;

            if (this.conversionTimer == 0) {
                this.finishCuring();
            }
        }
    }

    private void finishCuring() {
        Mob possessedEntity = this.getHost();

        if (possessedEntity != null) {
            RemnantComponent.get(this.player).curePossessed(possessedEntity);
        }
    }

    @Override
    public void writeToNbt(CompoundTag tag) {
        tag.putInt("conversionTimer", this.conversionTimer);
    }

    @Override
    public void readFromNbt(CompoundTag compound) {
        this.conversionTimer = compound.getIntOr("conversionTimer", 0);
    }

    public static double reachSq(BlockPos pos, Mob host) {
        double width = host.getBbWidth();
        double dx = (host.getX() + width / 2) - (pos.getX() + 0.5D);
        double dy = (host.getY() + host.getEyeHeight(host.getPose())) - (pos.getY() + 0.5D);
        double dz = (host.getZ() + width / 2) - (pos.getZ() + 0.5D);
        return dx * dx + dy * dy + dz * dz;
    }
}
