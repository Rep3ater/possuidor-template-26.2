package ladysnake.requiem;

import io.github.ladysnake.blabber.Blabber;
import ladysnake.requiem.api.v1.RequiemPlugin;
import ladysnake.requiem.api.v1.entity.ability.MobAbilityRegistry;
import ladysnake.requiem.api.v1.event.minecraft.SyncServerResourcesCallback;
import ladysnake.requiem.api.v1.remnant.SoulbindingRegistry;
import ladysnake.requiem.api.v1.util.SubDataManagerHelper;
import ladysnake.requiem.common.ApiInitializer;
import ladysnake.requiem.common.RequiemConfig;
import ladysnake.requiem.common.RequiemRecordTypes;
import ladysnake.requiem.common.RequiemRegistries;
import ladysnake.requiem.common.advancement.RequiemStats;
import ladysnake.requiem.common.advancement.criterion.RequiemCriteria;
import ladysnake.requiem.common.block.RequiemBlockEntities;
import ladysnake.requiem.common.block.RequiemBlocks;
import ladysnake.requiem.common.command.RemnantArgumentType;
import ladysnake.requiem.common.command.RequiemCommand;
import ladysnake.requiem.common.dialogue.RemnantChoiceDialogueAction;
import ladysnake.requiem.common.enchantment.RequiemEnchantments;
import ladysnake.requiem.common.entity.RequiemEntities;
import ladysnake.requiem.common.entity.RequiemEntityAttributes;
import ladysnake.requiem.common.entity.RequiemTrackedDataHandlers;
import ladysnake.requiem.common.entity.effect.RequiemStatusEffects;
import ladysnake.requiem.common.gamerule.RequiemGamerules;
import ladysnake.requiem.common.item.RequiemItems;
import ladysnake.requiem.common.loot.RequiemLootTables;
import ladysnake.requiem.common.network.RequiemNetworking;
import ladysnake.requiem.common.network.ServerMessageHandling;
import ladysnake.requiem.common.particle.RequiemParticleTypes;
import ladysnake.requiem.common.screen.RequiemScreenHandlers;
import ladysnake.requiem.common.sound.RequiemSoundEvents;
import ladysnake.requiem.common.structure.RequiemStructures;
import ladysnake.requiem.common.tag.RequiemEntityTypeTags;
import ladysnake.requiem.compat.RequiemCompatibilityManager;
import ladysnake.requiem.core.RequiemCore;
import ladysnake.requiem.core.remnant.VagrantInteractionRegistryImpl;
import ladysnake.requiem.core.resurrection.ResurrectionDataLoader;
import net.minecraft.commands.synchronization.ArgumentTypeInfos;
import net.minecraft.commands.synchronization.SingletonArgumentInfo;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.event.AddServerReloadListenersEvent;
import net.neoforged.neoforge.event.RegisterCommandsEvent;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

@Mod(Requiem.MOD_ID)
public final class Requiem {
    public static final String MOD_ID = "requiem";
    public static final Logger LOGGER = LogManager.getLogger("Requiem");

    public static Identifier id(String path) {
        return Identifier.fromNamespaceAndPath(MOD_ID, path);
    }

    public Requiem(IEventBus modEventBus) {
        RequiemCore.init();
        RequiemConfig.load();
        ApiInitializer.init();
        RequiemCriteria.init();
        RequiemBlocks.init();
        RequiemBlockEntities.init();
        RequiemTrackedDataHandlers.init();
        RequiemEnchantments.init();
        RequiemEntities.init();
        RequiemEntityAttributes.init();
        RequiemEntityTypeTags.init();
        RequiemGamerules.init();
        RequiemItems.init();
        RequiemLootTables.init();
        RequiemParticleTypes.init();
        RequiemRecordTypes.init();
        RequiemRegistries.init();
        RequiemScreenHandlers.init();
        RequiemSoundEvents.init();
        RequiemStats.init();
        RequiemStatusEffects.init();
        RequiemStructures.init();
        ServerMessageHandling.init();
        ApiInitializer.discoverEntryPoints();
        Blabber.registerAction(id("remnant_choice"), RemnantChoiceDialogueAction.CODEC);

        SingletonArgumentInfo<RemnantArgumentType> remnantArgInfo = SingletonArgumentInfo.contextFree(RemnantArgumentType::remnantType);
        ArgumentTypeInfos.registerByClass(RemnantArgumentType.class, remnantArgInfo);
        net.minecraft.core.Registry.register(BuiltInRegistries.COMMAND_ARGUMENT_TYPE, id("remnant"), remnantArgInfo);

        NeoForge.EVENT_BUS.addListener(this::onRegisterCommands);
        NeoForge.EVENT_BUS.addListener(this::onAddReloadListeners);

        SyncServerResourcesCallback.EVENT.register(player -> RequiemNetworking.sendTo(player, RequiemNetworking.createDataSyncMessage(SubDataManagerHelper.getServerHelper())));
        ApiInitializer.setPluginCallback(this::registerPlugin);
        RequiemCompatibilityManager.init();
    }

    private void onRegisterCommands(RegisterCommandsEvent event) {
        RequiemCommand.register(event.getDispatcher());
    }

    private void onAddReloadListeners(AddServerReloadListenersEvent event) {
        event.addListener(ResurrectionDataLoader.INSTANCE);
    }

    private void registerPlugin(RequiemPlugin plugin) {
        plugin.onRequiemInitialize();
        plugin.registerRemnantStates(RequiemRegistries.REMNANT_STATES);
        plugin.registerMobAbilities(MobAbilityRegistry.instance());
        plugin.registerSoulBindings(SoulbindingRegistry.instance());
        plugin.registerVagrantInteractions(VagrantInteractionRegistryImpl.INSTANCE);
        plugin.registerPossessionItemActions(RequiemRegistries.MOB_ACTIONS);
    }
}
