package io.github.ladysnake.blabber.impl.common;

import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;
import org.jetbrains.annotations.Nullable;

/** TODO(B1): placeholder, real dialogue engine port pending. */
public final class PlayerDialogueTracker {
    public static PlayerDialogueTracker get(Player player) {
        return new PlayerDialogueTracker();
    }

    public void startDialogue(Identifier id) {
        io.github.ladysnake.blabber.Blabber.LOGGER.warn("Dialogue engine not yet ported: {}", id);
    }

    public void endDialogue(@Nullable Identifier expected) {
    }
}